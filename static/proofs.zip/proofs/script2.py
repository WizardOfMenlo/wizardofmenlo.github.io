#!/usr/bin/env python3
"""
tarxz_and_report.py  –  create a compressed tarball (<file>.tar.xz) for every
regular file in the current directory and print the archive size (KiB) plus the
percentage size reduction (negative means the archive is larger).

Uses the strongest compression available in Python's tarfile module:
  • XZ/LZMA  → mode='w:xz', extension '.tar.xz'      (preferred)
  • Gzip     → mode='w:gz', extension '.tar.gz'      (fallback)

Python ≥3.6 required for f-strings.
"""

import tarfile
from pathlib import Path

# Decide which compression mode/extension we can use
try:
    import lzma  # noqa: F401  # will fail if Python lacks XZ/LZMA support
    TAR_MODE, EXT = 'w:xz', '.tar.xz'
except ModuleNotFoundError:
    TAR_MODE, EXT = 'w:gz', '.tar.gz'

def kib(bytes_: int) -> float:
    """Return size in kibibytes (KiB) with one decimal."""
    return bytes_ / 1024

def main() -> None:
    cwd = Path.cwd()
    print(f'Working directory: {cwd}  (compression: {TAR_MODE[2:]})\n')
    print(f'{"File":<30} {"Orig (KiB)":>12} {"Tar (KiB)":>10} {"Reduction":>11}')
    print('-' * 67)

    for path in sorted(cwd.iterdir()):
        if not path.is_file() or path.suffix == EXT:     # skip dirs/symlinks/our tarballs
            continue

        orig_size = path.stat().st_size
        if orig_size == 0:
            print(f'{path.name:<30} {"0":>12} {"—":>10} {"n/a":>11}')
            continue

        tar_name = path.with_suffix(path.suffix + EXT)   # e.g. foo.txt.tar.xz

        # Create (overwrite) the compressed tarball containing just this file
        with tarfile.open(tar_name, mode=TAR_MODE) as tf:
            tf.add(path, arcname=path.name)

        tar_size = tar_name.stat().st_size
        reduction_pct = (tar_size / orig_size) * 100

        print(f'{path.name:<30} {kib(orig_size):>12.1f} {kib(tar_size):>10.1f} {reduction_pct:>10.2f}%')

if __name__ == '__main__':
    main()

