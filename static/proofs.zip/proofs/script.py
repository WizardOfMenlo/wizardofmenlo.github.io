#!/usr/bin/env python3
"""
zip_and_report.py  –  create <filename>.zip for every regular file
in the current directory and print each archive's size (KiB) and the
compression ratio (percentage reduction).

Requires: Python ≥3.6 (for f-strings). No external programs needed.
"""

import os
import stat
import zipfile
from pathlib import Path

def human_kib(bytes_: int) -> float:
    """Return size in kibibytes (KiB) with one decimal place."""
    return bytes_ / 1024

def main() -> None:
    cwd = Path.cwd()
    print(f'Working directory: {cwd}\n')
    print(f'{"File":<30} {"Orig (KiB)":>12} {"Zip (KiB)":>10} {"Reduction":>11}')
    print('-' * 67)

    for path in sorted(cwd.iterdir()):
        # skip directories, symlinks, and existing .zip files
        if not path.is_file() or path.suffix == '.zip':
            continue

        orig_size = path.stat().st_size
        if orig_size == 0:         # avoid divide-by-zero
            print(f'{path.name:<30} {"0":>12} {"—":>10} {"n/a":>11}')
            continue

        zip_name = path.with_suffix(path.suffix + '.zip')

        # create (or overwrite) the zip archive containing this file
        with zipfile.ZipFile(zip_name, mode='w', compression=zipfile.ZIP_DEFLATED) as zf:
            zf.write(path, arcname=path.name)

        zip_size = zip_name.stat().st_size
        reduction_pct = (zip_size / orig_size) * 100

        print(f'{path.name:<30} {human_kib(orig_size):>12.1f} {human_kib(zip_size):>10.1f} {reduction_pct:>10.2f}%')

if __name__ == '__main__':
    main()

